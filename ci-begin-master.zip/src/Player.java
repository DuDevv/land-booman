import tklibs.SpriteUtils;

import java.awt.image.BufferedImage;

public class Player {
    BufferedImage PlayerImage;
    int location_x, location_y;
    public Player(){
        this.PlayerImage = SpriteUtils.loadImage("E:\\nhapmon\\ci-begin-master\\assets\\images\\players\\straight\\0.png");
        this.location_x = 308;
        this.location_y = 0;
    }
}
