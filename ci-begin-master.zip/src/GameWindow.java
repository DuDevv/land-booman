import javax.swing.*;

public class GameWindow extends JFrame {
    public GameWindow(){
        this.setVisible(true);
        this.setTitle("TOUHOU GAME");
        this.setSize(1000,1000);
        this.setResizable(false);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}
