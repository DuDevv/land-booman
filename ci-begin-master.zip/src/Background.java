import tklibs.SpriteUtils;

import java.awt.image.BufferedImage;

public class Background {
    BufferedImage BackgroundImage;
    int location_x, location_y;

    public Background() {
        this.BackgroundImage = SpriteUtils.loadImage("E:\\nhapmon\\ci-begin-master\\assets\\images\\background\\0.png");
        this.location_x = 308;
        this.location_y = 0;
    }
}
